from enum import Enum


class StatusType(Enum):
    """
    RecordStatusType Enum is used to indicate status of a Course, Module, Unit & Lesson
    """
    active = "Active"
    inactive = "Inactive"

