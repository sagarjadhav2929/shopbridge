from rest_framework import serializers
from inventory.models import Products


class ProductSerializer(serializers.ModelSerializer):

    class Meta:
        model = Products
        fields = ['product_name', 'price', 'status', 'slug', 'created_at', 'updated_at']


class ProductEditSerializer(serializers.ModelSerializer):

    class Meta:
        model = Products
        fields = ['product_name', 'price', 'status']


class ProductListSerializer(serializers.Serializer):
    def update(self, instance, validated_data):
        pass

    def create(self, validated_data):
        pass


class ProductValidationSerializer(serializers.Serializer):
    def update(self, instance, validated_data):
        pass

    def create(self, validated_data):
        pass

    slug = serializers.SlugField(required=True)
