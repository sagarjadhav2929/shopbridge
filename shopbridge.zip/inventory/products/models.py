from django.db import models

from inventory.models.abstract import TimeStampAbstractModel
from inventory.helpers.constants import StatusType


class Products(TimeStampAbstractModel):
    """
     Products model definition
    """
    product_name = models.CharField(max_length=235)
    slug = models.SlugField(max_length=255, unique=True, help_text="for making products urls", primary_key=True)
    status = models.CharField(
        max_length=10,
        choices=[(stype.name, stype.value) for stype in StatusType],
        default=StatusType.inactive
    )
    price = models.DecimalField(decimal_places=2, max_digits=9)
    short_description = models.CharField(max_length=235)

    class Meta:
        verbose_name = 'Product'
        verbose_name_plural = 'Products'
        db_table = verbose_name_plural.lower()

    def __str__(self):
        return "Product {}".format(self.product_name)
