from django.http import JsonResponse

from rest_framework.decorators import api_view, renderer_classes
from rest_framework.exceptions import NotFound
from rest_framework.renderers import JSONRenderer
from rest_framework.response import Response
from rest_framework import status
from inventory.models import Products
from inventory.products.serializers import ProductSerializer, ProductListSerializer, ProductValidationSerializer, \
    ProductEditSerializer


@api_view(['GET'])
@renderer_classes([JSONRenderer])
def product_details(request, product_id):
    """
    Retrieve Product details by id/slug
    """

    data = request.query_params.copy()
    data['slug'] = product_id
    request_data = ProductValidationSerializer(data=data)
    if not request_data.is_valid():
        return JsonResponse(request_data.errors, status=400)
    try:
        product = Products.objects.get(pk=product_id)
        serializer = ProductSerializer(product)
    except NotFound:
        raise NotFound({'Error': 'Product does not exists'}, 404)

    return Response(data=serializer.data)


@api_view(['GET'])
@renderer_classes([JSONRenderer])
def product_list(request):
    """
    List of Product available in system
    """
    data = request.query_params.copy()
    request_data = ProductListSerializer(data=data)
    if not request_data.is_valid():
        return JsonResponse(request_data.errors, status=400)
    try:
        product_list_search = Products.objects.all()
    except Products.DoesNotExist:
        raise NotFound({'Error': 'Not Product data found'}, 404)

    serializer = ProductSerializer(product_list_search, many=True)
    return Response(data=serializer.data)


@api_view(['PUT'])
@renderer_classes([JSONRenderer])
def edit_product(request, product_id):
    """
    Update Product Data: Update Product entity record details for given Product id.
    """
    data = request.data
    data['user'] = request.user.pk
    try:
        product = Products.objects.get(pk=product_id)
    except Products.DoesNotExist:
        return Response({'message': 'The Product does not exist'}, status=status.HTTP_404_NOT_FOUND)

    request_data = ProductEditSerializer(product, data=data)
    if not request_data.is_valid():
        return JsonResponse(request_data.errors, status=400)
    request_data.save()

    return Response(data={'message': "Success"}, status=status.HTTP_202_ACCEPTED)


@api_view(['DELETE'])
@renderer_classes([JSONRenderer])
def delete_product(request, product_id):
    """
    Delete Product Data: Delete Product record for given Product id.
    """
    data = request.data
    data['user'] = request.user.pk
    try:
        product = Products.objects.get(pk=product_id)
    except Products.DoesNotExist:
        return Response({'message': 'The Product does not exist'}, status=status.HTTP_404_NOT_FOUND)

    if product:
        product.delete()
        return Response(data={'message': "Success"}, status=status.HTTP_200_OK)


@api_view(['POST'])
@renderer_classes([JSONRenderer])
def create_product(request):
    """
    Create Product: Create Product with given details.
    """
    data = request.data
    data['user'] = request.user.pk

    product_data = ProductSerializer(data=data)
    if not product_data.is_valid():
        return JsonResponse(product_data.errors, status=400)
    product_data.save()

    return Response(data={'message': "Success"}, status=status.HTTP_202_ACCEPTED)

