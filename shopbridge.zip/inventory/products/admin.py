from django.contrib import admin

from inventory.products.models import Products


@admin.register(Products)
class ProductsAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug': ('product_name',)}
    list_display = ('product_name', 'price', 'status', 'slug')
    ordering = ('product_name',)
    list_filter = ('status',)

