from django.contrib import admin

from inventory.products.admin import *

admin.site.site_header = "Shop Bridge"

# Register your models here.
