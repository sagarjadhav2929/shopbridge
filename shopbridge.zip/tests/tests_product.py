import pytest
from inventory.products.api import edit_product

